package com.example.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.example.entity.Book;
import com.example.service.BookService;

@RestController
@Scope(value = "request")
public class BookController {

	@Autowired
	@Qualifier("bookService")
	BookService dao;
	
	@PostMapping(value="/books",produces= {MediaType.APPLICATION_JSON_VALUE},consumes= {MediaType.APPLICATION_JSON_VALUE})
	@ResponseStatus(code=HttpStatus.CREATED)
	public Book addBook(@RequestBody Book book) {
		return dao.addBook(book);
	}
	
	@PutMapping(value="/books",produces= {MediaType.APPLICATION_JSON_VALUE},consumes= {MediaType.APPLICATION_JSON_VALUE})
	@ResponseStatus(code=HttpStatus.OK)
	public Book updateBook(@RequestBody Book book) {
		return dao.updatebook(book);
	}
	

	
	@GetMapping(value="/books",produces= {MediaType.APPLICATION_JSON_VALUE})
	public List<Book> getAllBooks() {
		return dao.getallbooks();
	}
	
	@GetMapping(value="/books/{id}",produces= {MediaType.APPLICATION_JSON_VALUE})
	public Optional<Book> getBookById(@PathVariable("id") Integer id) {
		return dao.findbookbyid(id);
	}
	
	@DeleteMapping("/books/{id}")
	public void deleteBookById(@PathVariable("id") Integer id) {
		dao.deletebookbyid(id);
	}
	
	@GetMapping(value="/books/title/{book_title}",produces= {MediaType.APPLICATION_JSON_VALUE})

	public List<Book> getBookByTitle(@PathVariable("book_title") String title) {
		return dao.findBookbyName(title);
	}
	
	

	@GetMapping(value = "/books/publisher/{book_publisher}", produces = { MediaType.APPLICATION_JSON_VALUE })
	public List<Book> findBookbyPublisher(@PathVariable("book_publisher") String publisher) {
	    return dao.findBookbyPublisher(publisher); // corrected method name
	}
	

}
