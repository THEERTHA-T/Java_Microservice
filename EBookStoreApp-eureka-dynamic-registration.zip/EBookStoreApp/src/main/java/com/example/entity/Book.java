package com.example.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name="book_details")
public class Book {
	
	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	
	@Column(name = "BookTitle")
	private String title;
	
	@Column(name = "BookPublisher")
	private String publisher;
	
	@Column(name = "BookIsbn")
	private String isbn;
	
	@Column(name = "BookNumberOfPages")
	private int pages;
	
	@Column(name = "BookYear")
	private int year;

	

	public Book() {
		// Default constructor required by JPA
	}

	public Book(Integer id, String title, String publisher, String isbn, int pages, int year) {
		this.id = id;
		this.title = title;
		this.publisher = publisher;
		this.isbn = isbn;
		this.pages = pages;
		this.year = year;
	}}
