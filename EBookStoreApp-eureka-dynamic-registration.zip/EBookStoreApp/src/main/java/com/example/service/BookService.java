package com.example.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.example.entity.Book;
import com.example.repository.BookRepository;

@Service(value = "bookService")
@Scope(value = "singleton")
public class BookService implements IBookService {
	
	@Autowired
	@Qualifier(value="bookRepository")
	BookRepository repo;
	
	@Override
	public Book addBook(Book book) {
		return repo.save(book);

	}
	@Override
	public List<Book> getallbooks(){
		return repo.findAll();
	}
	
	@Override
	public Book updatebook(Book book) {
		return repo.save(book);
	}

	@Override
	public Optional<Book> findbookbyid(Integer id) {
		return repo.findById(id);
	}
	
	@Override
	public void deletebookbyid(Integer id) {
		repo.deleteById(id);
	}
	
	@Override
	public List<Book> findBookbyName(String name) {
		return repo.findByTitle(name);
	}
	
	@Override
	public List<Book> findBookbyPublisher(String publisher) {
		return repo.findByPublisher(publisher);
	}
	
	@Override
	public List<Book> findBookbyYear(int year){
		return repo.findByYear(year);
	}

	


}
