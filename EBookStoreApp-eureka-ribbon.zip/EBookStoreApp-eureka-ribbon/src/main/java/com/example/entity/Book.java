package com.example.entity;

import lombok.Data;

@Data

public class Book {

	private Integer id;

	private String title;

	private String publisher;

	private String isbn;

	private int pages;

	private int year;

	public Book() {
		// Default constructor required by JPA
	}

	public Book(Integer id, String title, String publisher, String isbn, int pages, int year) {
		this.id = id;
		this.title = title;
		this.publisher = publisher;
		this.isbn = isbn;
		this.pages = pages;
		this.year = year;
	}
}
