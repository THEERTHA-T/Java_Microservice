package com.mphasis.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.example.entity.Book;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@Service
public class BookService {
	

	@Autowired
	private RestTemplate restTemplate;
	
	@HystrixCommand(fallbackMethod="fallbackGetBookById")
	public Book getBookById(int id)
	{
		Book book=restTemplate.getForObject("http://product-service/books/"+id,Book.class);
		return book;
	}
	
	public Book fallbackGetBookById(int id)
	{

		return new Book(id, "book7", "publisher7", "123-777-789", 700, 2017);
	}

}
