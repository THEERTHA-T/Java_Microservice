package com.example.service;

import java.util.List;
import java.util.Optional;

import com.example.entity.Book;

public interface IBookService {
	
	public Book addBook(Book book);
	public List<Book> getallbooks();
	public Book updatebook(Book book);
	public Optional<Book> findbookbyid(Integer id);
	public void deletebookbyid(Integer id);
	public List<Book> findBookbyName(String name);
	public List<Book> findBookbyPublisher(String publisher);
	public List<Book> findBookbyYear(int year);
	
}
