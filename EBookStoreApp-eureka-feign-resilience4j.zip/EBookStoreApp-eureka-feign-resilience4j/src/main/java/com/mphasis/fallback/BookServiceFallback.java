package com.mphasis.fallback;

import java.util.List;

import org.springframework.stereotype.Component;
import java.util.ArrayList;

import com.example.entity.Book;
import com.mphasis.proxy.BookServiceProxy;

@Component
public class BookServiceFallback implements BookServiceProxy{

	@Override
	public List<Book> getAllBooks() {
		return new ArrayList<Book>();
	}

	@Override
	public Book getBookById(Integer id) {
		return new Book(id, "feign-hystrix", "fallback", "123-777-789", 700, 2017);
	}

}
