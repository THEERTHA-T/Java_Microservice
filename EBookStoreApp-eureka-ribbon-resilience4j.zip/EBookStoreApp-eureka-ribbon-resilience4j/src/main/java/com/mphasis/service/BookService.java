package com.mphasis.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.example.entity.Book;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;

@Service
public class BookService {
	

	@Autowired
	private RestTemplate restTemplate;
	
	@CircuitBreaker(name="product-service",fallbackMethod="fallbackGetBookById")
	public Book getBookById(int id)
	{
		Book book=restTemplate.getForObject("http://product-service/books/"+id,Book.class);
		return book;
	}
	
	public Book fallbackGetBookById(int id,Throwable cause)
	{
		System.out.println("Exception raised "+cause.getMessage());
		return new Book(id, "book7", "publisher7", "123-777-789", 700, 2017);
	}

}
